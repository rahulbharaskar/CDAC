//8.	Write a program to count down from 10 to 0, printing each number.

public class CountDown {
    public static void main(String[] args) {
        System.out.println("Counting down from 10 to 0:");
        for (int i = 10; i >= 0; i--) {
            System.out.println(i);
        }
    }
}
