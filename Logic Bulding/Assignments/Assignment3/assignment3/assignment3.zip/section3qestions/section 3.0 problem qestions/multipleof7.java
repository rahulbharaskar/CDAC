//3.	Write a program to print all multiples of 7 between 1 and 100.

public class multipleof7{
	public static void main(String args[]){
		System.out.println("Multiples of 7 between 1 and 100:");
		int i = 7;
		for( i=7; i<=100; i+=7){
			System.out.println(i);
		}
	}
}